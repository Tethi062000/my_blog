<!DOCTYPE html>
<html lang="en">
<body>	
	<center>
		<h1>Insert Form</h1>
		<form method="POST" action="insertData.php">
			<label>Name</label>
			<input type="text" placeholder="Enter name" name="f_name"> <br> <br>
			<label>Roll</label>
			<input type="text" placeholder="Enter roll" name="f_roll"> <br> <br>
			<label>Email</label>
			<input type="email"  placeholder="Enter email" name="f_email" > <br> <br>
			<input type="submit" value="INSERT">
		</form>
	</center>	
	
</body>
</html>